"""
Dự án: Dự đoán doanh thu đơn hàng (Revenue Prediction) - BẢN ĐƠN GIẢN
Bài toán: Regression (Hồi quy)
Áp dụng đúng 2 mô hình theo yêu cầu:
1. Linear Regression
2. Random Forest Regressor
"""

import pandas as pd
import numpy as np
import os
import sys

# Reconfigure stdout for Unicode support in Windows
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import r2_score
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression

def generate_mock_data():
    """Tạo dữ liệu giả lập để chạy code"""
    np.random.seed(42)
    n = 1000
    
    products = pd.DataFrame({
        'product_id': range(1, 11),
        'price': np.random.randint(100, 5000, 10) * 1000,
        'category_id': np.random.randint(1, 4, 10)
    })
    
    customers = pd.DataFrame({
        'customer_id': range(1, 101),
        'age': np.random.randint(18, 65, 100),
        'gender': np.random.choice(['Male', 'Female'], 100)
    })
    
    categories = pd.DataFrame({
        'category_id': [1, 2, 3],
        'category_name': ['Electronics', 'Clothing', 'Food']
    })
    
    dates = pd.date_range(start='2023-01-01', end='2023-12-31', periods=n)
    
    sales = pd.DataFrame({
        'order_id': range(1, n+1),
        'customer_id': np.random.choice(customers['customer_id'], n),
        'product_id': np.random.choice(products['product_id'], n),
        'quantity': np.random.randint(1, 10, n),
        'order_date': dates
    })
    
    sales.to_csv('sales.csv', index=False)
    customers.to_csv('customers.csv', index=False)
    products.to_csv('products.csv', index=False)
    categories.to_csv('categories.csv', index=False)

# Tạo data nếu chưa có
if not all(os.path.exists(f) for f in ['sales.csv', 'customers.csv', 'products.csv', 'categories.csv']):
    generate_mock_data()

print("\n--- 1. LOAD & PREPARE DATA ---")
sales = pd.read_csv("sales.csv")
customers = pd.read_csv("customers.csv")
products = pd.read_csv("products.csv")
categories = pd.read_csv("categories.csv")

# Clean
sales.fillna({'quantity': 1}, inplace=True)
customers.fillna({'age': customers['age'].median()}, inplace=True)
sales.drop_duplicates(inplace=True)
sales['order_date'] = pd.to_datetime(sales['order_date'])

# Merge
df = sales.merge(customers, on="customer_id", how="left") \
         .merge(products, on="product_id", how="left") \
         .merge(categories, on="category_id", how="left")

# Feature Engineering
df['month'] = df['order_date'].dt.month
df['revenue'] = df['quantity'] * df['price']

le_gender = LabelEncoder()
df['gender'] = le_gender.fit_transform(df['gender'])

le_category = LabelEncoder()
df['category_name'] = le_category.fit_transform(df['category_name'])

features = ['quantity', 'price', 'age', 'gender', 'category_name', 'month']
X = df[features]
y = df['revenue']

X_train, X_test, y_train, y_test = train_test_split(
   X, y, test_size=0.2, random_state=42
)

scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)


print("\n--- 9. Machine Learning Models ---")

# 🔹 9.1 Linear Regression
lr = LinearRegression()
lr.fit(X_train, y_train)

y_pred_lr = lr.predict(X_test)
print("LR R2:", r2_score(y_test, y_pred_lr))


# 🔹 9.2 Random Forest (Best baseline)
rf = RandomForestRegressor(n_estimators=100)
rf.fit(X_train, y_train)

y_pred_rf = rf.predict(X_test)
print("RF R2:", r2_score(y_test, y_pred_rf))
